import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { HeaderComponent } from "./header/header.component";
import { GalleryComponent } from "./gallery/gallery.component";
import { MainComponent } from "./main/main.component";
import { EndComponent } from "./end/end.component";
import { HomeComponent } from "./home/home.component";
import { TheendComponent } from "./theend/theend.component";
import { FooterComponent } from "./footer/footer.component";
import { MyroomComponent } from "./myroom/myroom.component";
import { AboutusComponent } from "./aboutus/aboutus.component";
import { TermsComponent } from "./terms/terms.component";
import { ContactComponent } from "./contact/contact.component";
import { LuxuryComponent } from "./luxury/luxury.component";

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, HeaderComponent, GalleryComponent, MainComponent, EndComponent, HomeComponent, TheendComponent, FooterComponent, MyroomComponent, AboutusComponent, TermsComponent, ContactComponent, LuxuryComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'web';
}
