import { Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { MyroomComponent } from './myroom/myroom.component';
import { AppComponent } from './app.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { TermsComponent } from './terms/terms.component';
import { HeaderComponent } from './header/header.component';
import { ContactComponent } from './contact/contact.component';
import { LuxuryComponent } from './luxury/luxury.component';

export const routes: Routes = [
    {path:"room",component:MyroomComponent},
    {path:"about",component:AboutusComponent},
    {path:"term",component:TermsComponent},
    {path:"header",component:HeaderComponent},
    {path:"contact",component:ContactComponent},
    {path:"luxury",component:LuxuryComponent},
    {path:"",component:HomeComponent}
];  
