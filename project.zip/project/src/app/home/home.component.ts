import { Component } from '@angular/core';
import { GalleryComponent } from "../gallery/gallery.component";
import { MainComponent } from "../main/main.component";
import { EndComponent } from "../end/end.component";
import { TheendComponent } from "../theend/theend.component";
import { FooterComponent } from "../footer/footer.component";
import { RouterLink, RouterModule, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [GalleryComponent, MainComponent, EndComponent, TheendComponent, FooterComponent,RouterLink,RouterModule,RouterOutlet],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent {

}
