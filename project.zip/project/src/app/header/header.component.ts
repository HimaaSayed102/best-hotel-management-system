import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { RouterLink, RouterModule, RouterOutlet } from '@angular/router';
import { HomeComponent } from "../home/home.component";
import { GalleryComponent } from "../gallery/gallery.component";
import { MainComponent } from "../main/main.component";
import { EndComponent } from "../end/end.component";
import { TheendComponent } from "../theend/theend.component";
import { FooterComponent } from "../footer/footer.component";

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [RouterLink, RouterModule, RouterOutlet, CommonModule, HomeComponent, GalleryComponent, MainComponent, EndComponent, TheendComponent, FooterComponent],
  templateUrl: './header.component.html',
  styleUrl: './header.component.css'
})
export class HeaderComponent {
  pageLanguage: 'fr' | undefined 


}
