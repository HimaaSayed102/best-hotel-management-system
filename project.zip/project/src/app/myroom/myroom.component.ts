import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { RouterLink, RouterModule, RouterOutlet } from '@angular/router';
import { HeaderComponent } from "../header/header.component";
import { EndComponent } from "../end/end.component";
import { FooterComponent } from "../footer/footer.component";

@Component({
  selector: 'app-myroom',
  standalone: true,
  imports: [RouterLink, RouterModule, CommonModule, RouterOutlet, HeaderComponent, EndComponent, FooterComponent],
  templateUrl: './myroom.component.html',
  styleUrl: './myroom.component.css'
})
export class MyroomComponent {
    showDetails = false;
  toggleDetails() {
    this.showDetails = !this.showDetails;
  }
  

}
