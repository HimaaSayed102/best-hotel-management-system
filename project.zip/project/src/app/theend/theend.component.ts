import { Component } from '@angular/core';

@Component({
  selector: 'app-theend',
  standalone: true,
  imports: [],
  templateUrl: './theend.component.html',
  styleUrl: './theend.component.css'
})
export class TheendComponent {

}
