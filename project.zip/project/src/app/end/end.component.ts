import { Component } from '@angular/core';
import { RouterLink, RouterModule, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-end',
  standalone: true,
  imports: [RouterLink,RouterOutlet,RouterModule],
  templateUrl: './end.component.html',
  styleUrl: './end.component.css'
})
export class EndComponent {

}
