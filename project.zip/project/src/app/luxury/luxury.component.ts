import { Component } from '@angular/core';
import { FooterComponent } from "../footer/footer.component";
import { RouterLink, RouterModule, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-luxury',
  standalone: true,
  imports: [FooterComponent,RouterLink,RouterModule,RouterOutlet],
  templateUrl: './luxury.component.html',
  styleUrl: './luxury.component.css'
})
export class LuxuryComponent {

}
